# instructions:

N M

c1 c2 ... cN

A11 A12 ... A1N * b1
A21 A22 ... A2N * b2
...
AM1 AM2 ... AMN * bM

'*' is '<', '>' or '='
