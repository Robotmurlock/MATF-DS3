# input format:

N M

A11 A12 ... A1N<br>
A21 A22 ... A2N<br>
    ...        <br>
AM1 AM2 ... AMN<br>

b1 b2 ... bm

x1 x2 ... xN