Upustvo za postavljanje problema:

n m

c11 c12 ... c1m a1
c21 c22 ... c2m a2
... ... ... ... ...
cn1 cn2 ... cnm an
b1  b2  ... bm